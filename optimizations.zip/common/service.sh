#!/system/bin/sh






function writeLock() {
	retry=0
	max_retries=20
		while [ "$(cat $1)" != "$2" ] && [ "$retry" -lt "$max_retries" ]; do
			chmod 000 "$1"
				chown root:root "$1"
					chmod u+rw "$1"
						echo "$2" > "$1"
							chmod a-w "1"
			retry=$((retry + 1))
				sleep 0.4
		done
		if [ "$(cat $1)" = "$2" ]; then
			echo "Sucess: successfully changed $1 value to $2" >> /data/local/log/results.txt
		else
			echo "Failure: failed to changed $1 value to $2" >> /data/local/log/results.txt
		fi
}

function refreshLogs() {
	echo "System Rebooted...!" > "$1"
}

function doFstrim() {
	/data/adb/magisk/busybox fstrim -v "$1" >> /data/local/log/fstrim.txt
}

refreshLogs /data/local/log/fstrim.txt
doFstrim /data
doFstrim /metadata
doFstrim /cache
doFstrim /data
doFstrim /metadata
doFstrim /cache
doFstrim /data
doFstrim /metadata
doFstrim /cache

refreshLogs /data/local/log/results.txt
chmod 000 /sys/devices/system/cpu/cpu0/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu1/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu2/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu3/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu4/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu5/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu6/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu7/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu0/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu1/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu2/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu3/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu4/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu5/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu6/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu7/topology/physical_package_id
writeLock /sys/devices/platform/soc/5000000.qcom,kgsl-3d0/devfreq/5000000.qcom,kgsl-3d0/governor "performance"
writeLock /sys/kernel/gpu/gpu_governor "performance"
writeLock /sys/devices/system/cpu/cpufreq/policy0/schedutil/down_rate_limit_us 2000
writeLock /sys/devices/system/cpu/cpufreq/policy0/schedutil/up_rate_limit_us 1000
writeLock /sys/devices/system/cpu/cpufreq/policy0/schedutil/hispeed_load 40
writeLock /sys/devices/system/cpu/cpufreq/policy0/schedutil/hispeed_freq 1804800
writeLock /sys/devices/system/cpu/cpufreq/policy0/schedutil/pl 0
writeLock /sys/devices/system/cpu/cpufreq/policy6/schedutil/down_rate_limit_us 2000
writeLock /sys/devices/system/cpu/cpufreq/policy6/schedutil/up_rate_limit_us 1000
writeLock /sys/devices/system/cpu/cpufreq/policy6/schedutil/hispeed_load 40
writeLock /sys/devices/system/cpu/cpufreq/policy6/schedutil/hispeed_freq 2208000
writeLock /sys/devices/system/cpu/cpufreq/policy6/schedutil/pl 0
writeLock /sys/class/kgsl/kgsl-3d0/throttling 0
writeLock /sys/class/kgsl/kgsl-3d0/thermal_pwrlevel 0
writeLock /sys/class/kgsl/kgsl-3d0/ifpc 0
writeLock /sys/class/kgsl/kgsl-3d0/acd 0
writeLock /sys/class/kgsl/kgsl-3d0/preemption 0
writeLock /sys/class/kgsl/kgsl-3d0/force_clk_on 1
writeLock /sys/class/kgsl/kgsl-3d0/force_bus_on 1
writeLock /sys/class/kgsl/kgsl-3d0/force_no_nap 1
writeLock /sys/class/kgsl/kgsl-3d0/force_rail_on 1
writeLock /sys/devices/system/cpu/cpu0/core_ctl/enable 0
writeLock /sys/devices/system/cpu/cpu6/core_ctl/enable 0
writeLock /proc/sys/vm/page-cluster 0
writeLock /sys/block/ram0/queue/read_ahead_kb 4096
writeLock /sys/block/ram1/queue/read_ahead_kb 4096
writeLock /sys/block/ram2/queue/read_ahead_kb 4096
writeLock /sys/block/ram3/queue/read_ahead_kb 4096
writeLock /sys/block/ram4/queue/read_ahead_kb 4096
writeLock /sys/block/ram5/queue/read_ahead_kb 4096
writeLock /sys/block/ram6/queue/read_ahead_kb 4096
writeLock /sys/block/ram7/queue/read_ahead_kb 4096
writeLock /sys/block/ram8/queue/read_ahead_kb 4096
writeLock /sys/block/ram9/queue/read_ahead_kb 4096
writeLock /sys/block/ram10/queue/read_ahead_kb 4096
writeLock /sys/block/ram11/queue/read_ahead_kb 4096
writeLock /sys/block/ram12/queue/read_ahead_kb 4096
writeLock /sys/block/ram13/queue/read_ahead_kb 4096
writeLock /sys/block/ram14/queue/read_ahead_kb 4096
writeLock /sys/block/ram15/queue/read_ahead_kb 4096
writeLock /sys/block/zram0/queue/read_ahead_kb 2048
stop mi_thermald
stop thermal-engine
