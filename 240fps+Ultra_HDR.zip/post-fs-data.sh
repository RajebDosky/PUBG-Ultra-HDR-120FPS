#!/system/bin/sh
MODDIR=${0%/*}
